from asyncio.windows_events import NULL
import pygame

class sector:
    x = 0
    y = 0
    number = 0
    type = NULL
    def __init__(self, xc, yc, nc):
        self.x = xc
        self.y = yc
        self.number = nc
    def x(self):
        return x
    def y(self):
        return y

pygame.init()
screeen = pygame.display.set_mode((700,500))
menu_right = pygame.image.load('image/rm.jpg')
menu_font = pygame.font.Font('font/PixelifySans-Medium.ttf', 30)
play_button = menu_font.render('Грати', True, 'white')
play_button_rect = play_button.get_rect(topleft=(30,150))
exit_button = menu_font.render('Вихід', True, 'white')
exit_button_rect = exit_button.get_rect(topleft=(30,200))


start_game = False
start_menu = True

while True:
    
    mouse= pygame.mouse.get_pos()
    if start_menu:

        click = pygame.mouse.get_pressed()[0]


        if play_button_rect.collidepoint(mouse) and not click:
            pygame.draw.circle(screeen, 'white', (150,170), 10 )
        elif play_button_rect.collidepoint(mouse) and click:
            print('грати')
            start_game = True
            start_menu = False
        elif exit_button_rect.collidepoint(mouse) and not click:
            pygame.draw.circle(screeen, 'white', (150,215), 10 )
        elif exit_button_rect.collidepoint(mouse) and click:
            print('вихід')
            pygame.quit()
        else:
            screeen.fill('black')
            screeen.blit(menu_right, (290,50))
            screeen.blit(play_button, play_button_rect)
            screeen.blit(exit_button, exit_button_rect)
    elif start_game:
        xm=0
        ym=0
        sectors_array = []
        for x in range (0,26):
            xm += 10
            sectors_array.append(sector(xm,ym,x))
        



        screeen.fill('black')
    
    
    
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()

    pygame.display.update()