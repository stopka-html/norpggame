from map import *
from uiInit import *
from buttons import *
from client import client

import pygame
pygame.init()


#image_path= "/data/data/com.test.myapp/files/app/" 
image_path= ""
clock = pygame.time.Clock()
game_font  = pygame.font.Font(image_path + 'font/PixelifySans-Medium.ttf', 10)

SCREEN_HEIGHT, SCREEN_WIDTH = 500,800

game_server_host = '127.0.0.1'
game_server_port = 12345


class Players_stat:
    avatar = pygame.image.load(image_path+'image/avt.jpeg')
    name = 0
    dmg = 1
    dfn = 0
    lvl = 0
    hp = 100
    mana = 100
    
    def __init__(self, name,hp,manna,avatar):
        self.name = game_font.render(name, True, 'white')
        self.hp = hp
        self.mana = manna
    def draw_stat(self, xn, yn):
        #game_hud.blit(self.avatar, (xn, yn))
        pygame.draw.rect(game_hud, 'green', pygame.Rect(xn+40,yn+15, self.hp, 10))
        pygame.draw.rect(game_hud, 'blue', pygame.Rect(xn+40,yn+20, self.mana, 10))
        game_hud.blit(self.name, (xn+45,yn))
        xl = xn+45
        undermen = [ self.dmg, self.dfn, self.lvl]
        for i in range(3):
            game_hud.blit(game_font.render(str(undermen[i]), True, 'white'), (xl+(45*i),yn+30))
            pygame.draw.rect(game_hud, 'white', (xl+(45*i)-5, yn+30, 20,15), 1)






# game hud screen
game_hud = pygame.Surface((200,500))
game_hud.fill('black')


scale = 1

screeen = pygame.display.set_mode((SCREEN_WIDTH,SCREEN_HEIGHT))
menu_right = pygame.image.load(image_path+'image/rm.jpg')
menu_font = pygame.font.Font(image_path+'font/PixelifySans-Medium.ttf', 30)



sock = client()



start_game = False
start_menu = True
running = True


def DrawMenuButtons():
    for i in main_menu_but:
            temp = menu_font.render(i.text, True, 'white')
            temp_rect = temp.get_rect(topleft=(i.collision_rect))
            screeen.blit(menu_font.render(i.text, True, 'white'), temp_rect)
            if temp_rect.collidepoint(mouse) and not click:
                pygame.draw.circle(screeen, 'white', (i.border_cord), 10 )
            if temp_rect.collidepoint(mouse) and click:
                if i.text == "Грати":
                    global start_menu, start_game
                    start_menu = False
                    start_game = True
                else:
                    global running 
                    running = False
            
            

def DrawMap():
    for i in range(len(sector_array)):
            sectors_array_rect = pygame.draw.polygon(screeen, 'white', sector_array[i].points)
            for k,j in sock.players_on_server.items():
                    
                    if j[3] == sector_array[i].number:
                        print(j[4])
                        player = pygame.draw.circle(screeen, j[4], (sector_array[i].points[0][0],sector_array[i].points[0][1]+15),4)
            
            if sectors_array_rect.collidepoint(pygame.mouse.get_pos()):
                print(sector_array[i].number, sector_array[i].points[0])

def DrawMapButton():
    for i in range(len(move_but)):
            move_but_rect = pygame.draw.rect(screeen, 'red', pygame.Rect(move_but[i].x, move_but[i].y, move_but[i].a, move_but[i].a))
            if move_but_rect.collidepoint(pygame.mouse.get_pos()) and click:
                for it in range(len(sector_array)):
                    move_but[i].clickme(it)

def DrawPlayersStat():
    sock.recv_stats()
    players = []
    for i,j in sock.players_on_server.items():
          players.append(Players_stat(i,j[0],j[1],123))
    y_stats = 10
    for i in players:
            i.draw_stat(10,y_stats)
            y_stats += 50
while running:
    
    mouse= pygame.mouse.get_pos()
    click = pygame.mouse.get_pressed()[0]
    if start_menu:

        click = pygame.mouse.get_pressed()[0]
        screeen.fill('black')
        DrawMenuButtons()
        screeen.blit(menu_right, (290,50))
    elif start_game:
        print(sock.players_on_server)
        sock.send_stats(100,100)
        keys = pygame.key.get_pressed()
        screeen.fill('black')
        DrawMap()
        DrawMapButton()
        
        screeen.blit(game_hud, (600,0))
        DrawPlayersStat()
    for event in pygame.event.get():
        
        if event.type == pygame.QUIT:
            running = False
            
            pygame.quit()

    pygame.display.update()
    clock.tick(60)

pygame.quit()