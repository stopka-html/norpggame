import socket
import time
import json
# Створюємо сокет
client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
players = []
name = 'baka2'
manna= 100
hp = 100
game_class = 'range'
players_on_server = dict()
# Підключаємося до сервера
server_address = ('127.0.0.1', 12345)
client_socket.connect(server_address)


client_socket.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, False)
while True:
    # send our data
    
    data_to_send = name+','+str(manna)+','+str(hp)+','+game_class+';'
    print("sended: ",data_to_send)
    client_socket.sendall(data_to_send.encode())
    # Отримуємо відповідь від сервера
    
    players = []
    data = client_socket.recv(1024)
    data = list(data.decode())
    if ':' in data and '/' in data:
        num_players = int(data[1])
        
        i = data.index(":")+2
        for k in range(0,num_players):
            names = ''
            j = 0
            hps = ''
            mannas = ''
            gclasss = ''
            
            while data[i] != ';':
                
                if j == 0:
                    names += data[i]
                    if data[i+1]==',':
                        
                        j += 1
                        i += 2
                        continue
                if j == 1:
                    mannas += data[i]
                    if data[i+1]==',':
                        
                        j += 1
                        i += 2
                        continue
                if j == 2:
                    hps += data[i]
                    if data[i+1]==',':
                        
                        j += 1
                        i += 2
                        continue
                if j == 3:
                    gclasss += data[i]
                i += 1
            i += 1
                        
            players_on_server.update({names:[hps,mannas,gclasss]})
    
    time.sleep(1)



