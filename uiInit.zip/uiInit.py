from map import move_button
from buttons import *
move_but = [move_button('left', 40, 400, 25),
            move_button('right', 80, 400,25), 
            move_button('up', 60, 375,25), 
            move_button('down', 60, 425,25)]
main_menu_but = [main_menu_butons('Грати',[30,150],[150,170]), main_menu_butons('Вихід',[30,200],[150,215])]