import main
class Game:
    gameid = 0
    game_class = ['melle']
    m_num = 0
    