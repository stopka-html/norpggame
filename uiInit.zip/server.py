import socket
import time
import json
import random
# Створюємо сокет
server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

# Задаємо IP-адресу та порт для прослуховування
server_address = ('127.0.0.1', 12345)
server_socket.bind(server_address)

# Починаємо слухати запити
server_socket.listen(5)
print('Сервер слухає на {}:{}'.format(*server_address))
server_socket.setblocking(0)
connected = []
colors = ['black','blue','red','yellow','green']
players_on_server = dict()
server_socket.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, True)
resp = ''
old_resp = ''
while True:
    
    try:
        
        client_socket, client_address = server_socket.accept()
        client_socket.setblocking(0)
        print('Підключено до {}'.format(client_address))
        connected.append(client_socket)
        
        
    except:
        pass
    
    for sock in connected:

        try:
            
            data = sock.recv(2000)
            data = list(data.decode())
            
            name = ''
            j = 0
            hp = ''
            manna = ''
            poss = ''
            gclass = ''
            colore = ''
            i = 0
            while data[i] != ';':
                
                if j == 0:
                    name += data[i]
                    if data[i+1]==',':
                        
                        j += 1
                        i += 2
                        continue
                if j == 1:
                    manna += data[i]
                    if data[i+1]==',':
                        
                        j += 1
                        i += 2
                        continue
                if j == 2:
                    hp += data[i]
                    if data[i+1]==',':
                        
                        j += 1
                        i += 2
                        continue
                if j == 3:
                    gclass += data[i]
                    if data[i+1]==',':
                        
                        j += 1
                        i += 2
                        continue
                if j == 4:
                    poss += data[i]
                    if data[i+1]==',':
                        
                        j += 1
                        i += 2
                        continue
                if j == 5:
                    colore += data[i]
                     
                i += 1
            if colore == '#':
                colore = colors[random.randint(0,len(colors))]
            
            players_on_server.update({name:[int(hp),int(manna),gclass,int(poss),colore]})
        except:
            pass
        
        


    for sock in connected:
        try:
            resp = ''
            for i,j in players_on_server.items():
                
                
                resp = resp+i+','+str(j[0])+','+str(j[1])+','+j[2]+','+str(j[3])+','+str(j[4])+';'
                
            resp = ':'+str(len(players_on_server))+resp+'/:'
            
            sock.sendall(resp.encode())
        except:
            pass
    time.sleep(0.01)

    



