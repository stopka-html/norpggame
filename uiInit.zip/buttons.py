class main_menu_butons():
    text = ""
    collision_rect = []
    border_cord = []
    def __init__(self, text, cords, bc):
        self.text = text
        self.collision_rect = cords
        self.border_cord = bc
