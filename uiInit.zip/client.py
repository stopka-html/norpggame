import socket
import time
import json
import random


class client:
    
    def __init__(self):
        self.client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.client_socket.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, True)
        self.name = 'baka'
        self.colore = '#'
        self.manna = 100
        self.hp = 100
        self.pos = random.randint(0,500)
        self.game_class = 'range'
        self.players_on_server = dict()
        self.server_address = ('127.0.0.1', 12345)
        self.client_socket.connect(self.server_address)
        data_to_send = self.name+','+str(self.manna)+','+str(self.hp)+','+self.game_class+','+ str(self.pos) + ',' + self.colore +';'
        self.old_data_to_send = ''
        
        self.client_socket.sendall(data_to_send.encode())
    def self_update(self):
        try:
            self.colore = self.players_on_server[self.name][4]
        except:
            self.colore = 'white'
    def send_stats(self,hp,manna):
        data_to_send = self.name+','+str(manna)+','+str(hp)+','+self.game_class+','+ str(self.pos) + ',' + self.colore +';'
        print(data_to_send)
        if data_to_send != self.old_data_to_send:
            self.client_socket.sendall(data_to_send.encode())
            self.old_data_to_send = data_to_send
    def recv_stats(self):
        self.players_on_server = dict()
        data = self.client_socket.recv(1024)
        data = list(data.decode())
        print(data)
        if (':' in data) and ('/' in data) and data[data.index(':')+1] != ':' :
            
            num_players = int(data[data.index(':')+1])
            
            i = data.index(":")+2
            for k in range(0,num_players):
                names = ''
                j = 0
                hps = ''
                mannas = ''
                gclass = ''
                posss = ''
                colores = ''
                while data[i] != ';':
                    
                    if j == 0:
                        names += data[i]
                        if data[i+1]==',':
                            
                            j += 1
                            i += 2
                            continue
                    if j == 1:
                        mannas += data[i]
                        if data[i+1]==',':
                            
                            j += 1
                            i += 2
                            continue
                    if j == 2:
                        hps += data[i]
                        if data[i+1]==',':
                            
                            j += 1
                            i += 2
                            continue
                    if j == 3:
                        gclass += data[i]
                        if data[i+1]==',':
                        
                            j += 1
                            i += 2
                            continue
                    if j == 4:
                        posss += data[i]
                        if data[i+1]==',':
                        
                            j += 1
                            i += 2
                            continue
                    if j == 5:
                        colores += data[i]
                    
                    i += 1
                i += 1
                            
                self.players_on_server.update({names:[int(hps),int(mannas),gclass,int(posss),colores]})
                self.self_update()


