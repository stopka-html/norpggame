import pygame

def initMap():
    x1 = 30
    y1 = 0 
    i = 0
    num = 1
    c = 0
    sector_array = []
    for it in range(0,626):
    
        points = [[x1 + (20 * i) -c , y1], [(x1-10) + (20*i) - c, (y1+10)], [(x1-10)+(20*i) - c, (y1+20)], [x1+(20*i)-c, y1+30], [(x1+10)+(20*i)-c, (y1+20)], [(x1+10)+(20*i)-c, (y1+10)]]
        sector_array.append(sector(points, it))
    
        if i == 24:
            i = 0
        
            y1 += 25
        else:
            i += 1

        if num == 25 and c == 0:
            c = 10
            num = 0
        elif num == 25 and c == 10:
            c = 0
            num = 0
        num += 1
    return sector_array

class sector():
    x = 0
    points= []
    y = 0
    number = 0
    def __init__(self, points, number):
        self.points = points
        self.number = number
    def move_left(self):
        for i in range(len(self.points)):
            self.points[i][0] = self.points[i][0] - 1
    def move_right(self):
        for i in range(len(self.points)):
            self.points[i][0] = self.points[i][0] + 1
    def move_up(self):
        for i in range(len(self.points)):
            self.points[i][1] = self.points[i][1] - 1
    def move_down(self):
        for i in range(len(self.points)):
            self.points[i][1] = self.points[i][1] + 1

class move_button():
    stype = ''
    x , y = 0, 0
    a = 0
    def __init__(self, type, x, y, a):
        self.stype = type
        self.x = x
        self.y = y
        self.a = a
        
    def clickme(self,i):
        if self.stype == 'left':
            sector_array[i].move_left()
        if self.stype == 'right':
            sector_array[i].move_right()
        if self.stype == 'up':
            sector_array[i].move_up()
        if self.stype == 'down':
            sector_array[i].move_down()

sector_array = initMap()